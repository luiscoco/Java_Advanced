package com.luxoft.lmd;

import java.util.stream.Stream;

public class StatefulShortCircuiting {
	public static void main(String[] args) {
		System.out.println("=== dropWhile()");
		Stream.of(1, 2, 3, 1, 2, 3, 4)
			.dropWhile(val -> val <= 2)
			.forEach(System.out::println);

		System.out.println("=== filter()");
		Stream.of(1, 2, 3, 1, 2, 3, 4)
			.filter(val -> val <= 3)
			.forEach(System.out::println);

		System.out.println("=== takeWhile()");
		Stream.of(1, 2, 3, 1, 2, 3, 4)
			.takeWhile(val -> val <= 2)
			.forEach(System.out::println);
	}
}
