package com.luxoft.lmd;

import java.util.function.Predicate;
import java.util.stream.Stream;

public class Predicates {
	public static void main(String[] args) {
		System.out.println("=== 1");
		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.filter(v -> v > 3)
			.filter(v -> v < 8)
			.forEach(System.out::println);


		System.out.println("=== 2");
		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.filter(v -> v < 3 || v < 8)
			.forEach(System.out::println);

		System.out.println("=== 3");
		Predicate<Integer> firstP = integer -> integer < 3;
		Predicate<Integer> secondP = integer -> integer > 8;

		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.filter(firstP.or(secondP))
			.forEach(System.out::println);

		Stream.of(1, 2, 3, 4, 5, 6, 4, 7, 8, 9)
			.filter(Predicate.isEqual(4).negate())
			.findFirst();

	}
}
