package com.luxoft.lmd;

import java.util.stream.Stream;

public class Finders {
	public static void main(String[] args) {
		int first =
			Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
				.findFirst()
				.orElse(0);
	}
}
