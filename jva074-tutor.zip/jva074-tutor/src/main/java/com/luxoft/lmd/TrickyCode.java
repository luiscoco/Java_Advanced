package com.luxoft.lmd;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.stream.Stream;

public class TrickyCode {
	public static void main(String[] args) {
		System.out.println("Hello and welcome!");

		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.peek(System.out::println)
			.forEach(i -> System.out.println("always print " + i));

		long count = Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.map(value -> value + 1)
			.filter(integer -> integer > 3)
			.peek(i -> {
				System.out.println("never print" + i);
			}).count();

		Stream.of(9, 8, 7, 6)
			.sorted()
			.forEach(i -> System.out.println("sorted " + i));

		Stream.of("Taras", "Alexandra", "Andrii")
			.peek(i -> {
				System.out.println("never print " + i);
			})
			.sorted((Comparator<String>) Comparator.naturalOrder().reversed())
			.forEach(i -> System.out.println("sorted " + i));

		System.out.println(" Example with Sorted Set ");
		TreeSet<String> set = new TreeSet<>();
		set.add("Taras");
		set.add("Alexandra");
		set.add("Andrii");

		set.stream()
			.peek(i -> {
				System.out.println("1. never print " + i);
			})
			.sorted()
			.count();

		System.out.println("count = " + count);
		System.out.println("Bye bye!");

		// that is OK
		List<Integer> result = new ArrayList<>();
		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.filter(val -> val > 3)
			.forEach(result::add);

		// that is very PRO stuff
		ConcurrentLinkedQueue<Integer> threadSafeStructure
			= new ConcurrentLinkedQueue<>();
		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.filter(val -> val > 3)
			.forEach(threadSafeStructure::add);
	}
}
