package com.luxoft.lmd;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StatefulRunToCompletion {
	public static void main(String[] args) {
		System.out.println("=== distinct()");
		Stream.of(1, 2, 3, 1, 2, 3, 4)
			.distinct()
			.forEach(System.out::println);

		// alternative
		Stream.of(1, 2, 3, 1, 2, 3, 4)
			.collect(Collectors.toSet());

		System.out.println("=== sorted()");
		Stream.of(1, 2, 3, 1, 2, 3, 4)
			.sorted()
			.forEach(System.out::println);


		System.out.println("=== skip()");
		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
			.skip(4)
			.limit(2) // that is short cuircuiting, not run to completion
			.forEach(System.out::println);
	}
}
