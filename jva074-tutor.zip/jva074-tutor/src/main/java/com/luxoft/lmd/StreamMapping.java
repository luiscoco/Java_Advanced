package com.luxoft.lmd;

import java.util.function.Function;
import java.util.function.UnaryOperator;
import java.util.stream.Stream;

public class StreamMapping {

	public static void print(int x, UnaryOperator<Integer> f) {
		System.out.println(f.apply(x));
	}

	public static void main(String[] args) {
		UnaryOperator<Integer> f1 = a -> a + 1;
		UnaryOperator<Integer> f2 = a -> a * 2;

		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.map(f1)
			.map(f2);

		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.map(f1.andThen(f2));

		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.map(f2)
			.map(f1);

		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.map(f1.compose(f2));


		Function<Integer, Integer> func = Function.identity();
		UnaryOperator<Integer> func1 = UnaryOperator.identity();
		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.map(value -> value)
			.map(func)
			.map(func1);




		int x = 1;
		System.out.println(f1.andThen(f2).apply(x));  // f2(f1(x)) =4
		System.out.println(f1.compose(f2).apply(x));  // f1(f2(x)) =3
		UnaryOperator<Integer> f3 = UnaryOperator.identity();
		print(10, f1);
		print(10, UnaryOperator.identity());
		print(10, z -> z);
	}
}
