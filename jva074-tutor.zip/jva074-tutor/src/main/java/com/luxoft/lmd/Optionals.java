package com.luxoft.lmd;

import java.util.Optional;

public class Optionals {
	public static void main(String[] args) {

		var value1 = Optional.empty();
		var value2 = Optional.of(new Reducers.Person("Leszek", 25));
		var value3 = Optional.ofNullable( null );

		int age = 0;
		if (value2.isPresent())
			age = value2.get().age();

		value2.map(Reducers.Person::age).filter(ageValue -> ageValue > 18).orElse( -1 );


		// kotlin code

		// var person: Person? = null
		// var person: Person = new Person( "leszek", 22 )
		// person?.age?.takeIf { it > 18 } ?: -1
/*
		System.out.println("result2.isEmpty() = " + value2.isEmpty());

		value2.ifPresent(value -> {
			System.out.println("we got the value " + value);
		});

		value2.ifPresentOrElse(System.out::println, () -> System.out.println("I got no value"));

		Integer valueWithFallback = value2.orElse(0);
		value2.orElseGet(() -> aValueWhichComputesForVeryLong());

		value2.orElseThrow();

		value2.orElseThrow(() -> new RuntimeException());
		// result2.orElseThrow(myService::createException);*/
	}

	private static Integer aValueWhichComputesForVeryLong() {
		return null;
	}
}
