package com.luxoft.lmd;

import java.util.Optional;
import java.util.OptionalInt;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Reducers {
	public record Person(String firstName, int age) {
	}

	public static void main(String[] args) {

		Optional<Integer> result1 =
			Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
				.reduce((left, right) -> {
					System.out.println("a + b: " + left + " + " + right);
					return left + right;
				});

		Integer sum = Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.reduce(0, Integer::sum);

		Integer factorial = Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.reduce(1, (left, right) -> left * right);

		Optional<Integer> reduce =
			Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
				.reduce((left, right) -> {
					if (left < right)
						return left;
					else return right;
				});

		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.count();

		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.reduce(0, (left, right) -> left++);

		OptionalInt min = Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.mapToInt(value -> value)
			.min();

		Stream.of(new Person("leszek", 18), new Person("martha", 22))
			.mapToInt(Person::age)
			.min();
		// .max();
		// .average();

		IntStream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.min();

		Stream<Integer> boxed = IntStream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.boxed();

		Stream<String> stringStream = IntStream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.mapToObj(value -> "Hello number " + value);


/*
		Optional<Integer> result2 =
			Stream.<Integer>empty()
				.reduce((left, right) -> {
					System.out.println("a + b: " + left + " + " + right);
					return left + right;
				});
*/

		// please don't
		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.reduce((a, b) -> a - b);

		String reduce1 =
			Stream.of("Hello", "World", "Something")
				.reduce("", (s, s2) -> s + " " + s2);

		Stream.of("Hello", "World", "Something")
			.reduce((s1, s2) -> {
				if (s1.length() > s2.length())
					return s1;
				else
					return s2;
			});

		Stream.of("Hello", "World", "Something")
			.reduce((s1, s2) -> {
				if (s1.compareTo(s2) > 0)
					return s1;
				else
					return s2;
			});
	}

}
