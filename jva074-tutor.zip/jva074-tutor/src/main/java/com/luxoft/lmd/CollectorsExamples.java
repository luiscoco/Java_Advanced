package com.luxoft.lmd;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.stream.Collectors.*;

public class CollectorsExamples {
	public static void main(String[] args) {
		Set<Integer> distinctValues =
			Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 9, 9, 9)
				.collect(toSet());

		// this is a mutable collection you can modify it
		List<Integer> collect =
			Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 9, 9, 9)
				.collect(toList());


		// there is no .toSet() variant
		List<Integer> immutableList =
			Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 9, 9, 9)
				.toList();


		// please don't!
		// immutableList.clear();

		List<Integer> result =
			Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 9, 9, 9)
				.collect(toCollection(LinkedList<Integer>::new));


		Map<Character, String> result1 =
			Stream.of("John", "Paul", "George", "Ringo", "Paul", "John", "Paul", "Peter")
				.collect(
					toMap(
						value -> value.charAt(0),
						Function.identity(),
						(left, right) -> right
					));
		System.out.println("result1 = " + result1);

		Map<Character, List<String>> result2 =
			Stream.of("John", "Paul", "George", "Ringo", "Paul", "John", "Paul", "Peter")
				.collect(groupingBy(value -> value.charAt(0)));

		System.out.println("result2 = " + result2);

		Map<Character, Long> result3 =
			Stream.of("John", "Paul", "George", "Ringo", "Paul", "John", "Paul", "Peter")
				.collect(
					groupingBy(
						value -> value.charAt(0),
						Collectors.counting()
					)
				);

		System.out.println("result3 = " + result3);

		String collect1 = Stream.of("John", "Paul", "George", "Ringo", "Paul", "John", "Paul", "Peter")
			.collect(
				joining(", ", "All names = [", "]")
			);

		System.out.println("collect1 = " + collect1);


		Map<Character, String> collect2 =
			Stream.of("John", "Paul", "George", "Ringo", "Paul", "John", "Paul", "Peter")
				.collect(
					groupingBy(
						value -> value.charAt(0),
						joining("+")
					)
				);

		System.out.println("collect2 = " + collect2);


		String s =
			Stream.of("John", "Paul", "George", "Ringo", "Paul", "John", "Paul", "Peter", "A long name")
				.max((o1, o2) -> o1.length() - o2.length())
				.orElse(null);

		System.out.println("longest name: " + s);

		Stream.of("John", "Paul", "George", "Ringo", "Paul", "John", "Paul", "Peter", "A long name")
			.max(Comparator.comparing(str -> str.length()))
			.orElse(null);

		Stream.of("John", "Paul", "George", "Ringo", "Paul", "John", "Paul", "Peter", "A long name")
			.max(Comparator.comparing(String::length))
			.orElse(null);

		String maxByName = Stream.of("John", "Paul", "George", "Ringo", "Paul", "John", "Paul", "Peter", "A long name")
			.max(Comparator.naturalOrder())
			.orElse(null);

		System.out.println("maxByName = " + maxByName);


		Map<Character, Optional<String>> collect3 =
			Stream.of("John", "Paul", "George", "Ringo", "Paul", "John", "Paul", "Peter", "P Very Long Name")
			.collect(
				groupingBy(
					value -> value.charAt(0),
					maxBy(Comparator.comparing(String::length))
				)
			);

		System.out.println("collect3 = " + collect3);
	}
}
