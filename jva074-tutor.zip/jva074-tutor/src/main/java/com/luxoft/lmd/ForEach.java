package com.luxoft.lmd;

import java.util.function.Consumer;
import java.util.stream.Stream;

public class ForEach {
	public static void main(String[] args) {
		System.out.println("==== 1");
		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.forEach(value -> System.out.println(value));

		System.out.println("==== 2");
		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.forEach(System.out::println);

		System.out.println("==== 3");
		Consumer<Integer> consumer1 = s -> System.out.println("first consumer " + s);
		Consumer<Integer> consumer2 = s -> System.out.println("second consumer " + s);

		Consumer<Integer> composite = consumer1.andThen(consumer2);

		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.forEach(composite);

	}
}
