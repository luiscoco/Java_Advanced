package com.luxoft.lmd;

import java.util.stream.Stream;

public class BooleanReductions {
	public static void main(String[] args) {
		// true
		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.allMatch(val -> val > 0);

		// true
		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.noneMatch(val -> val > 100);

		// true
		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9)
			.anyMatch(val -> val >= 8);
	}
}
