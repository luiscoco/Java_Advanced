package com.luxoft.lmd;

import net.datafaker.Faker;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class Main implements Runnable {
	public record Product(String code, String name) {
	}

	public record OrderPosition(Product product, double price, int quantity) {
	}

	public record Order(String customerCode, LocalDateTime date, List<OrderPosition> positions) {
	}

	private Faker faker = new Faker();

	private List<Product> products;

	public Main() {
		this.products =
			faker.collection(
					() -> new Product(faker.code().ean13(), faker.commerce().productName()))
				.len(10)
				.generate();
	}

	public Product randomProduct() {
		return products.get(ThreadLocalRandom.current().nextInt(products.size()));
	}

	@Override public void run() {
			String value = "one, two, three";

		Stream<String> stringStream = Pattern.compile(",").splitAsStream(value);
	}

	public static void main(String[] args) {
		new Main().run();
	}
}