package com.luxoft.lmd;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;

public class FlatMapper {
	public class Person {
		private String firstName;
		private String lastName;

		private List<Person> children;

		public String getFirstName() {
			return firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public List<Person> getChildren() {
			return children;
		}
	}

	public static void main(String[] args) {
		List<Integer> list1 = Arrays.asList(1, 2, 3, 4, 5, 6, 7);
		List<Integer> list2 = Arrays.asList(2, 4, 6);
		List<Integer> list3 = Arrays.asList(3, 5, 7);

		Stream.of(list1, list2, list3)
			.forEach(System.out::println);

		System.out.println("=== flattened");
		Stream.of(list1, list2, list3)
			.flatMap(Collection::stream)
			.forEach(System.out::println);

/*
		Stream<Person> persons = null;
		persons.flatMap(person -> person.getChildren().map( child -> child.getFirstName()).stream())
			.toString();
*/
		Stream<Person> persons = null;
		List<String> list = persons
			.mapMulti((Person person, Consumer<String> consumer) -> {
				person.getChildren().forEach(child -> consumer.accept(child.getFirstName()));
			})
			.toList();

	}
}
