package com.luxoft.lmd.datastreams.sequential;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;

public class StatefulRunToCompletion {
	@Test
	public void distinct() {
		List<Integer> list = Stream.of(1, 2, 3, 1, 2, 3, 4)
			.distinct()
			.toList();

		assertIterableEquals(
			List.of(1, 2, 3, 4),
			list
		);
	}

	@Test
	public void toSet() {
		Set<Integer> result =
			Stream.of(1, 2, 3, 1, 2, 3, 4)
				.collect(Collectors.toSet());

		assertEquals(
			Set.of(4, 3, 2, 1),
			result
		);
	}

	@Test
	public void sorted() {
		List<Integer> sorted =
			Stream.of(1, 2, 3, 1, 2, 3, 4)
				.sorted()
				.toList();

		assertEquals(
			List.of(1, 1, 2, 2, 3, 3, 4),
			sorted
		);
	}

	@Test
	public void skip() {
		List<Integer> list = Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
			.skip(4)
			.limit(2) // that is short cuircuiting, not run to completion
			.toList();

		assertEquals(
			List.of(5, 6),
			list
		);
	}
}
