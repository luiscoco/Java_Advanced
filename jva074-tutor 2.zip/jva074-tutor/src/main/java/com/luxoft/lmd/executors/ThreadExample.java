package com.luxoft.lmd.executors;

import com.google.common.hash.HashCode;
import com.google.common.hash.Hashing;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ThreadExample {
	private final static Logger LOGGER = LoggerFactory.getLogger(ThreadExample.class);

	public static void main(String[] args) {
		LOGGER.info("starting our app");
		Thread thread = new Thread(ThreadExample::doSomething);
		thread.setDaemon(true);
		thread.start();


		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		}

		thread.interrupt();

		try {
			thread.join();
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		}

		LOGGER.info("that is a finish of the app!");
	}

	public static void doSomething() {
		long value = 0;

		while (value++ < Long.MAX_VALUE) {
			if (Thread.currentThread().isInterrupted()) {
				LOGGER.info("got interrupted");
				break;
			}
			HashCode hashCode = Hashing.hmacSha512(new byte[100]).hashBytes(new byte[1000000]);
		}
		LOGGER.info("something!!");
	}
}
