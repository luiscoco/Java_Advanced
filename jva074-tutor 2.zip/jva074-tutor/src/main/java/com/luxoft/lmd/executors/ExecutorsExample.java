package com.luxoft.lmd.executors;

import com.google.common.base.Stopwatch;
import com.luxoft.lmd.model.Person;
import net.datafaker.Faker;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.slf4j.MDC.MDCCloseable;

import java.util.List;
import java.util.Set;
import java.util.concurrent.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.*;

public class ExecutorsExample {
	private final static Logger logger = LoggerFactory.getLogger(ExecutorsExample.class);
	private final static Faker faker = new Faker();

	@Test
	public void executorServiceLifeCycle() {
		ExecutorService executor = Executors.newSingleThreadExecutor();

		executor.execute(() -> logger.info("Hello World!"));

		// shutdown executed in phases

		// I. Graceful shutdown
		//    - no new tasks are accepted
		//    - running tasks are allowed to finish
		//    - all queued tasks have a chance to still run
		executor.shutdown();
		try {
			// waiting at most the specified time,
			// if queued tasks finish earlier awaitTermination finishes ASAP
			executor.awaitTermination(10, TimeUnit.HOURS);
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		}
		// ungraceful shutdown, queued tasks are removed and not started
		// queued tasks are returned as the result of shutdownNow()
		// all running tasks are interrupted - those are not in shutdownNow() result

		// please mind that interrupted tasks might not finish right away,
		// if they dont respond properly to interruptions
		executor.shutdownNow();
	}

	@Test @DisplayName("ExecutorService is AutoCloseable in Java 19+")
	public void executorServiceAutoCloseable() {
		try (ExecutorService executorService = Executors.newSingleThreadExecutor()) {
			executorService.execute(() -> logger.info("Hello world!"));
		}
	}

	@Test @DisplayName("waiting for task to finish")
	public void waitingForTaskToFinish() {
		try (ExecutorService executorService = Executors.newSingleThreadExecutor()) {
			Future<?> future = executorService.submit(ExecutorsExample::doSomethingLongRunning);

			try {
				Object result = future.get();
				logger.info("the result of submitting Runnable is: {}", result);
			} catch (InterruptedException | ExecutionException e) {
				throw new RuntimeException(e);
			}
		}
	}

	@Test @DisplayName("waiting for task to finish without blocking")
	public void waitingForTaskToFinishWithoutBlocking() {
		try (ExecutorService executorService = Executors.newSingleThreadExecutor()) {
			Future<?> future = executorService.submit(ExecutorsExample::doSomethingLongRunning);

			while (true) {
				if (future.isDone()) {
					logger.info("finally the task is over!");
					break;
				} else {
					logger.info("doing something else...");
					sleep(500);
				}
			}
		}
	}

	@Test @DisplayName("lambda task returning a result")
	public void gettingResultFromTask_LambdaVersion() {
		try (ExecutorService executorService = Executors.newSingleThreadExecutor()) {
			Future<Person> future =
				executorService.submit(
					() -> {
						logger.info("task started emulating long computation");
						sleep(3000);
						Person person = new Person(
							faker.funnyName().name(),
							Person.Gender.MALE,
							45,
							2
						);
						logger.info("result computed");
						return person;
					}
				);

			// for now ignore the exception handling
			try {
				Person person = future.get();
				logger.info("result from task: {}", person);
			} catch (InterruptedException | ExecutionException e) {
				throw new RuntimeException(e);
			}
		}
	}

	@Test @DisplayName("lambda task returning a result")
	public void gettingResultFromTask_MethodReferenceVersion() {
		try (ExecutorService executorService = Executors.newSingleThreadExecutor()) {
			Future<Person> future = executorService.submit(ExecutorsExample::computePerson);

			try {
				Person person = future.get();
				logger.info("result from task: {}", person);
			} catch (InterruptedException | ExecutionException e) {
				throw new RuntimeException(e);
			}
		}
	}

	@Test @DisplayName("task throwing an exception")
	public void taskThrowingException() {
		try (ExecutorService executorService = Executors.newSingleThreadExecutor()) {
			Future<Person> future =
				executorService.submit(() -> {
					throw new RuntimeException("there will be no person");
				});

			ExecutionException executionException = assertThrows(ExecutionException.class, future::get);

			assertAll(
				() -> assertNotNull(executionException.getCause()),
				() -> assertEquals("there will be no person", executionException.getCause().getMessage())
			);
		}
	}

	@Test @DisplayName("cancelling a task")
	public void cancellingTask() {
		try (ExecutorService executorService = Executors.newSingleThreadExecutor()) {
			Future<Person> future = executorService.submit(ExecutorsExample::computePerson);
			// the task taskes 5 seconds
			sleep(1000);

			// we have changed our minds - we do not want the task to run
			// the task is currently running though

			logger.info("task done: {}, cancelled: {}", future.isDone(), future.isCancelled());
			logger.info("cancelling task");
			boolean taskCouldBeCancelled = future.cancel(false);
			logger.info("task could be cancelled: {}", taskCouldBeCancelled);

			assertTrue(taskCouldBeCancelled);

			do {
				logger.info("task done: {}, cancelled: {}", future.isDone(), future.isCancelled());
				sleep(500);
			} while (!future.isDone());

			logger.info("we are not allowed to retrieve data from cancelled task, it will raise CancellationException");

			assertAll(
				() -> assertThrows(CancellationException.class, future::get),
				() -> assertTrue(future::isDone),
				() -> assertTrue(future::isCancelled)
			);
			;
		}
	}

	@Test @DisplayName("cancelling a task with interruption")
	public void cancellingTaskWithInterruption() {
		try (ExecutorService executorService = Executors.newSingleThreadExecutor()) {
			Future<Person> future = executorService.submit(ExecutorsExample::computePerson);
			// the task takes 5 seconds
			sleep(1000);

			boolean taskCouldBeCancelled = future.cancel(true);
			logger.info("task could be cancelled: {}", taskCouldBeCancelled);

			assertAll(
				() -> assertTrue(taskCouldBeCancelled),
				() -> assertThrows(CancellationException.class, future::get),
				() -> assertTrue(future::isDone),
				() -> assertTrue(future::isCancelled)
			);

		}
	}

	@Test @DisplayName("cancelling already finished task")
	public void cancellingAlreadyFinishedTask() {
		try (ExecutorService executorService = Executors.newSingleThreadExecutor()) {
			Future<Person> future = executorService.submit(ExecutorsExample::computePerson);
			sleep(6000);

			logger.info("attempting task cancel");
			boolean taskCouldBeCancelled = future.cancel(true);

			assertAll(
				() -> assertFalse(taskCouldBeCancelled),
				() -> assertFalse(future::isCancelled),
				() -> assertTrue(future::isDone),
				() -> assertDoesNotThrow(() -> future.get())
			);
		}
	}

	@Test @DisplayName("awaiting multiple tasks")
	public void awaitingMultipleTasks() {
		try (ExecutorService executorService = Executors.newFixedThreadPool(5)) {
			// first submit all
			List<Future<Person>> futures =
				IntStream.range(0, 10)
					.mapToObj(index -> executorService.submit(ExecutorsExample::computePerson))
					.toList();

			// then process, why two steps?
			String finalResult =
				futures.stream()
					.map(personFuture -> {
						try {
							return personFuture.get();
						} catch (InterruptedException | ExecutionException e) {
							throw new RuntimeException(e);
						}
					})
					.map(Person::name)
					.collect(Collectors.joining(", "));

			logger.info("final result: {}", finalResult);
		}
	}

	@Test @DisplayName("cached thread pool should create a thread for every separate task")
	public void cachedThreadPool() {
		class ThreadNameProvider implements Callable<String> {
			@Override public String call() throws Exception {
				Thread.sleep(3);
				return Thread.currentThread().getName();
			}
		}

		try (ExecutorService executorService = Executors.newCachedThreadPool()) {
			List<Callable<String>> tasks
				= IntStream.range(0, 100)
				.boxed()
				.<Callable<String>>map(index -> new ThreadNameProvider())
				.toList();

			try {
				List<Future<String>> futures = executorService.invokeAll(tasks);
				Set<String> threadNames =
					futures.stream().map(
						future -> {
							try {
								return future.get();
							} catch (InterruptedException | ExecutionException e) {
								throw new RuntimeException(e);
							}
						}
					).collect(Collectors.toSet());

				logger.info("thread count used: {}, this might be lower than the number of tasks!", threadNames.size());

			} catch (InterruptedException e) {
				throw new RuntimeException(e);
			}
		}
	}

	@Test @DisplayName("virtual threads")
	public void virtualThreads() throws InterruptedException, ExecutionException {
		class RandomValueProvider implements Callable<Integer> {
			@Override public Integer call() throws Exception {
				int value = ThreadLocalRandom.current().nextInt(10);
				Thread.sleep(value);
				return value;
			}
		}

		try (ExecutorService service = Executors.newVirtualThreadPerTaskExecutor()) {
			logger.info("starting up massive amount of tasks");

			Stopwatch watch = Stopwatch.createStarted();

			List<RandomValueProvider> tasks = IntStream.range(0, 100_000)
				.boxed()
				.map(index -> new RandomValueProvider())
				.toList();

			List<Future<Integer>> futures = service.invokeAll(tasks);

			futures.forEach(future -> {
				try {
					future.get();
				} catch (InterruptedException | ExecutionException e) {
					throw new RuntimeException(e);
				}
			});

			watch.stop();
			logger.info("finished all tasks!, time elapsed: {}ms", watch.elapsed().toMillis());
		}
	}

	@Test @DisplayName("virtual task without executor")
	public void virtualTaskWithoutExecutor() {
		Thread.ofVirtual().start(() -> logger.info("Hi! I am a virtual thread!"));
	}

	private static void sleep(int sleepLength) {
		try {
			Thread.sleep(sleepLength);
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		}
	}

	public static void doSomethingLongRunning() {
		logger.info("task started");

		sleep(5000);

		logger.info("task finished");
	}

	// compared to Runnable - Callable or method mapping tu Callable interface is allowed to throw
	public static Person computePerson() throws Exception {
		String name = faker.funnyName().name();

		try (
			MDCCloseable ignored = MDC.putCloseable("name", name)
		) {
			logger.info("task started");
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				logger.error("got interrupted", e);
			}
			Person person =
				new Person(
					name,
					Person.Gender.MALE,
					45,
					2
				);
			logger.info("task finished");
			return person;
		}

	}
}
