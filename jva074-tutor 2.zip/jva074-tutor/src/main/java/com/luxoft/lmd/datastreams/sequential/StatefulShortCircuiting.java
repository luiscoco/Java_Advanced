package com.luxoft.lmd.datastreams.sequential;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertIterableEquals;

public class StatefulShortCircuiting {
	@Test
	public void dropWhile() {
		List<Integer> list =
			Stream.of(1, 2, 3, 1, 2, 3, 4)
				.dropWhile(val -> val <= 2)
				.toList();

		assertIterableEquals(
			List.of(3, 1, 2, 3, 4),
			list
		);
	}

	@Test
	public void takeWhile() {
		List<Integer> result =
			Stream.of(1, 2, 3, 1, 2, 3, 4)
				.takeWhile(val -> val <= 2)
				.toList();

		assertIterableEquals(
			List.of(1, 2),
			result
		);
	}

	@Test
	public void limit() {
		List<Integer> list =
			Stream.of(1, 2, 3, 1, 2, 3, 4)
				.limit(3)
				.toList();

		assertIterableEquals(
			List.of(1, 2, 3),
			list
		);
	}

	// filter is stateless - just for comparison
	@Test
	public void filter() {
		List<Integer> result =
			Stream.of(1, 2, 3, 1, 2, 3, 4)
				.filter(val -> val <= 2)
				.toList();

		assertIterableEquals(
			List.of(1, 2, 1, 2),
			result
		);
	}

}
