package com.luxoft.lmd.datastreams.parallel;

import com.google.common.hash.Hashing;
import net.datafaker.Faker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ForkJoinPool;
import java.util.function.Supplier;
import java.util.stream.IntStream;
import java.util.stream.LongStream;
import java.util.stream.Stream;

public class Benchmark {
	public static final Logger logger = LoggerFactory.getLogger(Benchmark.class);
	private static Faker faker = new Faker();

	public static void main(String[] args) {
		logger.info("fork join pool parallelism: " + ForkJoinPool.getCommonPoolParallelism());
		int testCount = 10;

		int dataSize = 1_000;
		while (dataSize <= 1_000_000_000) {
			runAllBenchmarks(dataSize, testCount);
			dataSize *= 10;
		}
	}

	private static void runAllBenchmarks(int dataSize, int testCount) {
		NumberFormat format = NumberFormat.getNumberInstance(Locale.US);

		var dataSizeStr = format.format(dataSize);
		//benchmark(dataSizeStr + "-SumForLoop", testCount, () -> sumForLoop(dataSize));
		//benchmark(dataSizeStr + "-Sum", testCount, () -> sum(dataSize));
		//benchmark(dataSizeStr + "-SumParallel", testCount, () -> sumParallel(dataSize));

		//benchmark(dataSizeStr + "-Sqrt", testCount, () -> sqrt(dataSize));
		//benchmark(dataSizeStr + "-SqrtParallel", testCount, () -> sqrtParallel(dataSize));

		//benchmark(dataSizeStr + "-Hash", testCount, () -> hashing(dataSize, false));
		//benchmark(dataSizeStr + "-HashParallel", testCount, () -> hashing(dataSize, true));

		//benchmark(dataSizeStr + "-processSeq", testCount, () -> processInefficient(dataSize, false));
		//benchmark(dataSizeStr + "-processInefficientParallel", testCount, () -> processInefficient(dataSize, true));
		//benchmark(dataSizeStr + "-processEfficientParallel", testCount, () -> processEfficient(dataSize));

		List<String> values = new ArrayList<>(faker.collection(() -> faker.funnyName().name()).len(dataSize).generate());
		benchmark(dataSizeStr + "-stringsFromCollection", testCount, () -> processStringsFromSplitableSource(values));
		benchmark(dataSizeStr + "-stringsFromGenerate", testCount, () -> processStringsFromGeneratedSource(values));

		logger.info("---");
	}

	private static <V> void benchmark(String taskNamePrefix, int count, Callable<V> task) {
		// warmup
		Timing.runTimed(null, task);

		try (var closeable = MDC.putCloseable("task", taskNamePrefix)) {
			double averageRunningTime =
				IntStream.range(0, count)
					.mapToObj(index -> taskNamePrefix + "[" + index + "]")
					.map(taskName -> Timing.runTimed(taskName, task))
					.mapToLong(value -> value.duration().toNanos())
					.average().orElseThrow();

			logger.info("avg: {}ns, {}ms", Math.round(averageRunningTime), Math.round(averageRunningTime / 10000) / 100.0);
		}
	}


	private static long sum(long count) {
		return LongStream.range(0, count)
			.sum();
	}

	private static long sumParallel(long count) {
		return LongStream.range(0, count)
			.parallel()
			.sum();
	}

	private static long sumForLoop(long count) {
		long acc = 0;
		for (long i = 0; i < count; i++)
			acc += i;
		return acc;
	}

	private static double sqrt(long count) {
		return LongStream.range(0, count)
			.mapToDouble(op -> Math.sqrt((double) op))
			.sum();
	}

	private static double sqrtParallel(long count) {
		return LongStream.range(0, count)
			.parallel()
			.mapToDouble(op -> Math.sqrt((double) op))
			.map(Math::sqrt)
			.map(Math::sqrt)
			.map(Math::sqrt)
			.map(Math::sqrt)
			.sum();
	}

	private static long hashing(long count, boolean parallel) {
		LongStream stream = LongStream.range(0, count);
		if (parallel)
			stream = stream.parallel();

		return stream
			.map(value -> Hashing.sha512().hashBytes(longToBytes(value)).asInt())
			.sum();
	}

	private static double processInefficient(long count, boolean parallel) {
		Stream<Integer> stream =
			Stream.iterate(2, i -> i + 1);

		if (parallel)
			stream.parallel();

		return stream
			.filter(i -> i % 2 == 0)
			.limit(count)
			.map(Math::sqrt)
			.map(Math::sqrt)
			.map(Math::sqrt)
			.mapToDouble(Math::sqrt)
			.sum();
	}

	private static double processEfficient(long count) {
		return LongStream.range(2, (count * 2) + 1)
			.parallel()
			.mapToDouble(Math::sqrt)
			.map(Math::sqrt)
			.map(Math::sqrt)
			.map(Math::sqrt)
			.sum();
	}

	private static long processStrings(Stream<String> streamSupplier) {
		return streamSupplier
			//.flatMap(s -> Arrays.stream(s.split("")))
			//.count();
			.mapToInt(s -> s.length())
			.sum();
	}

	private static long processStringsFromSplitableSource(List<String> collection) {
		return processStrings(collection.parallelStream());
	}

	private static long processStringsFromGeneratedSource(List<String> collection) {
		Supplier<String> iterator = new Supplier<String>() {
			int idx = 0;

			@Override public String get() {
				return collection.get(idx++);
			}
		};

		return processStrings(Stream.generate(() -> iterator.get()).limit(collection.size()).parallel());
	}


	public static byte[] longToBytes(long value) {
		byte[] bytes = new byte[8]; // since long is 8 bytes
		for (int i = 7; i >= 0; i--) {
			bytes[i] = (byte) (value & 0xFF);
			value >>= 8; // Shift right by 8 bits to process the next byte
		}
		return bytes;
	}
}
