import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.luxoft.lmd.model.Person;
import net.datafaker.Faker;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.TreeSet;
import java.util.function.BinaryOperator;
import java.util.function.Function;

import static com.luxoft.lmd.model.Person.Gender.FEMALE;
import static com.luxoft.lmd.model.Person.Gender.MALE;
import static java.util.stream.Collectors.*;

public class CollectorsTaskBuilder {
	private final ObjectMapper mapper = new ObjectMapper();
	private final Faker faker = new Faker();
	private final ObjectWriter writer = mapper.writerWithDefaultPrettyPrinter();

	private void writeResult(String taskNumber, Object result) throws IOException {
		writer.writeValue(new File("src/main/resources/task1-" + taskNumber + ".json"), result);
	}

	public void run() throws IOException {
		Collection<Person> people =
			faker.collection(
				() -> {
					Person.Gender gender = faker.random().nextBoolean() ? MALE : FEMALE;
					return new Person(
						gender == MALE ? faker.name().malefirstName() : faker.name().femaleFirstName(),
						gender,
						faker.random().nextInt(25, 60),
						faker.random().nextInt(0, 4)
					);
				}
			).len(120).generate();

		writer.writeValue(new File("src/main/resources/task1-people.json"), people);


		writeResult(
			"01",
			people.stream().collect(groupingBy(Person::gender, counting()))
		);
		writeResult(
			"02",
			people.stream().collect(groupingBy(Person::gender, mapping(Person::name, joining(", ", "#{ ", " }#"))))
		);
		writeResult(
			"03",
			people.stream().filter(person1 -> person1.gender() == FEMALE)
				.mapToInt(Person::age).average().orElseThrow()
		);
		writeResult(
			"04",
			people.stream().collect(groupingBy(Person::gender, averagingInt(Person::age))
			));
		writeResult(
			"05",
			people.stream().sorted(Comparator.comparing(Person::name)).toList()
		);
		writeResult(
			"06",
			people.stream().sorted(Comparator.comparing(Person::gender).thenComparing(Person::name)).toList()
		);
		writeResult(
			"07",
			people.stream().collect(toMap(Person::gender, Function.identity(), BinaryOperator.maxBy(Comparator.comparing(Person::age))))
		);

		writeResult(
			"08",
			people.stream().filter(person -> person.gender() == FEMALE).map(Person::name).collect(toSet())
		);

		// list of males males older than 40 with no children

		writeResult(
			"09",
			people.stream()
				.filter(person -> person.gender() == MALE)
				.filter(person -> person.age() >= 40)
				.filter(person -> person.childCount() == 0)
				.toList()
		);

		writeResult(
			"10",
			people.stream().collect(groupingBy(Person::gender, groupingBy(Person::age, mapping(Person::name, toCollection(TreeSet::new)))))
		);

		writeResult("11", people.stream().mapToInt(Person::childCount).sum());

		writeResult("12",
			people.stream().collect(teeing(counting(), summingInt(Person::childCount), (personCount, childCount) -> personCount + childCount))
		);

		writeResult(
			"13",
			people.stream().collect(groupingBy(person -> person.name().length(), counting()))
		);

		writeResult(
			"14",
			people.stream().map(Person::name).flatMap(name -> Arrays.stream(name.split(""))).count()
		);

		writeResult("15",
			people.stream()
				.collect(groupingBy(Person::gender, mapping(Person::name, flatMapping(name -> Arrays.stream(name.split("")), counting()))))
		);

	}

	public static void main(String[] args) throws IOException {
		new CollectorsTaskBuilder().run();
	}
}
