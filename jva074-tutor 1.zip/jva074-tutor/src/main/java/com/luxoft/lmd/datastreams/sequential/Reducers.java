package com.luxoft.lmd.datastreams.sequential;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.function.BinaryOperator;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

public class Reducers {
	@Test @Order(1)
	public void sumLambda() {
		Optional<Integer> result =
			Stream.of(1, 2, 3, 4)
				.reduce((left, right) -> {
					// uncomment to see how many reductions are made
					// System.out.println("a + b: " + left + " + " + right);
					return left + right;
				});

		assertAll(
			() -> assertTrue(result.isPresent()),
			() -> assertEquals(10, result.get())
		);
	}

	@Test @Order(2)
	public void sumLambdaEmptyStream() {
		Optional<Integer> result =
			Stream.<Integer>empty()
				.reduce((left, right) -> left + right);

		assertAll(
			() -> assertTrue(result.isEmpty())
		);
	}

	@Test @Order(3)
	public void sumLambdaSingleElementStream() {
		Optional<Integer> result =
			Stream.of(1)
				.reduce((left, right) -> {
					throw new RuntimeException("never runs");
				});

		assertAll(
			() -> result.isPresent(),
			() -> assertEquals(1, result.get())
		);
	}

	@Test @Order(4)
	public void sumFunctionReference() {
		Integer result =
			buildSimpleIntStream()
				.reduce(Integer::sum)
				.orElse(-1);

		assertEquals(45, result);
	}

	@Test @Order(5)
	public void sumWithIdentityElement() {
		// no need for optional
		Integer result =
			buildSimpleIntStream()
				.reduce(0, Integer::sum);
		assertEquals(45, result);
	}

	@Test @Order(6)
	public void sumEmptyStream() {
		Integer result =
			Stream.<Integer>empty()
				.reduce(0, Integer::sum);

		assertEquals(0, result);
	}

	@Test @Order(7)
	public void factorialWithProperIdentityElement() {
		Integer result = buildSimpleIntStream()
			.reduce(1, (left, right) -> left * right);

		// 9!
		assertEquals(362880, result);
	}

	@Test @Order(8)
	public void minimum() {
		Optional<Integer> result = buildSimpleIntStream()
			.reduce((left, right) -> {
				if (left < right)
					return left;
				return right;
			});

		assertAll(
			() -> assertTrue(result.isPresent()),
			() -> assertEquals(1, result.get())
		);
	}

	@Test @Order(9)
	public void minimumMethodRef() {
		Optional<Integer> result = buildSimpleIntStream()
			.reduce(Integer::min);

		assertAll(
			() -> assertTrue(result.isPresent()),
			() -> assertEquals(1, result.get())
		);
	}

	@Test @Order(10)
	public void count() {
		long result = buildSimpleIntStream().count();
		assertEquals(9, result);
	}


	@Test @Order(11)
	public void reducePersonsSumAllAges() {
		record Person(String firstName, int age) {
		}

		int sum =
			Stream.of(
					new Person("Leszek", 18),
					new Person("Martha", 22)
				).mapToInt(Person::age)
				.sum(); // min(), max(), average()

		assertEquals(40, sum);
	}

	@Test @Order(12)
	public void reducePersonsSumAllAgesAlternate() {
		record Person(String firstName, int age) {
		}

		int sum =
			Stream.of(
				new Person("Leszek", 18),
				new Person("Martha", 22)
			).reduce(0,
				(accumulator, person) -> accumulator + person.age(),
				(left, right) -> left + right
			);

		assertEquals(40, sum);
	}

	@Test @Order(13)
	@DisplayName("don't reduce using non associative functions")
	public void nonAssociative() {
		Optional<Integer> result =
			buildSimpleIntStream()
				.reduce((a, b) -> a - b);

		System.out.println(result.get());
		System.out.println("You will get non deterministic results in parallel execution");
	}

	@Test @Order(14)
	public void stringReduction() {
		System.out.println("VERY INEFFICIENT but working, always use a collector for that!");
		Optional<String> result =
			Stream.of("a", "b", "c")
				.reduce((s, s2) -> s + ":" + s2);

		assertEquals("a:b:c", result.get());
	}

	@Test @Order(15)
	public void minStringWithReduce() {
		System.out.println("prefer Collectors.minBy to this implementation");
		List<String> list = List.of("abc", "ab", "c", "d");

		Optional<String> result1 =
			list.stream()
				.reduce((s1, s2) -> {
					if (s1.length() <= s2.length())
						return s1;
					return s2;
				});

		Optional<String> result1a =
			list.stream()
				.reduce(BinaryOperator.minBy(Comparator.comparing(String::length)));

		Optional<String> result2 =
			list.stream()
				.reduce((s1, s2) -> {
					if (s1.length() < s2.length())
						return s1;
					return s2;
				});

		Optional<String> result3 = list.stream()
			.reduce(
				BinaryOperator.minBy(Comparator.naturalOrder())
			);

		assertAll(
			() -> assertEquals("c", result1.get()),
			() -> assertEquals("c", result1a.get()),
			() -> assertEquals("d", result2.get()),
			() -> assertEquals("ab", result3.get())
		);
	}

	@Test @Order(16)
	public void minDirectly() {
		List<String> list = List.of("abc", "ab", "c", "d");

		Optional<String> result2 =
			list.stream()
				.min(Comparator.comparing(String::length));

		Optional<String> result3 =
			list.stream()
			.min(Comparator.naturalOrder());

		assertAll(
			() -> assertEquals("c", result2.get()),
			() -> assertEquals("ab", result3.get())
		);
	}

	private static Stream<Integer> buildSimpleIntStream() {
		return Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9);
	}
}
