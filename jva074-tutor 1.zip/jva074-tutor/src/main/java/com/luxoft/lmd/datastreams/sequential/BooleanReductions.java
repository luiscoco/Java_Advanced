package com.luxoft.lmd.datastreams.sequential;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class BooleanReductions {
	private static Stream<Integer> buildStream() {
		return Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9);
	}

	@Test
	@DisplayName("check if all elements of a stream match a condition")
	public void allMatch() {
		assertTrue(
			buildStream()
				.allMatch(val -> val > 0) // short circuiting
		);
	}

	@Test
	@DisplayName("check if none of elements of a stream match a condition")
	public void noneMatch() {
		assertTrue(
			buildStream()
				.noneMatch(val -> val > 100) // short circuiting
		);

		assertFalse(
			buildStream()
				.noneMatch(val -> val > 5)
		);
	}

	@Test
	@DisplayName("check if any element of a stream matches a condition")
	public void anyMatch() {
		assertTrue(
			buildStream()
				.anyMatch(val -> val > 3) // short circuits
		);
	}
}
