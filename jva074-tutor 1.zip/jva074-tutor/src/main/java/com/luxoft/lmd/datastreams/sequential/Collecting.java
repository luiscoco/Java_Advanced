package com.luxoft.lmd.datastreams.sequential;

import com.luxoft.lmd.model.Person;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.*;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.luxoft.lmd.model.Person.Gender.FEMALE;
import static com.luxoft.lmd.model.Person.Gender.MALE;
import static java.util.stream.Collectors.maxBy;
import static java.util.stream.Collectors.toMap;
import static org.junit.jupiter.api.Assertions.*;

// not to clash with Collectors class name
public class Collecting {
	private static Stream<Integer> createIntStream() {
		return Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 9, 9, 9);
	}

	@Test
	public void toList() {
		List<Integer> result =
			createIntStream().collect(Collectors.toList());

		assertIterableEquals(
			List.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 9, 9, 9),
			result
		);
	}

	@Test
	public void toSet() {
		Set<Integer> distinctValues =
			createIntStream().collect(Collectors.toSet());

		assertEquals(
			Set.of(1, 2, 3, 4, 5, 6, 7, 8, 9),
			distinctValues
		);
	}

	@Test
	public void mutability() {
		// creates a mutable list
		List<Integer> collectorsToList = createIntStream().collect(Collectors.toList());

		// immutable list variants
		List<Integer> collectorsToUnmodifiableList = createIntStream().collect(Collectors.toUnmodifiableList());
		List<Integer> toList = createIntStream().toList();

		assertAll(
			() -> assertDoesNotThrow(collectorsToList::clear),
			() -> assertThrows(UnsupportedOperationException.class, collectorsToUnmodifiableList::clear),
			() -> assertThrows(UnsupportedOperationException.class, toList::clear)
		);
	}

	// specify your own collection to collect to
	@Test
	public void toCollection() {
		LinkedList<Integer> result =
			Stream.of(1, 2, 3, 4)
				.collect(Collectors.toCollection(LinkedList<Integer>::new));

		Assertions.assertEquals(LinkedList.class, result.getClass());
	}

	// using toMap() in simplest form if the keys are unique
	@Test
	public void toMapNoDuplicates() {
		Map<Character, String> result =
			Stream.of("John", "Paul", "George", "Ringo")
				.collect(toMap(value -> value.charAt(0), Function.identity()));

		assertEquals(
			Map.of(
				'J', "John",
				'P', "Paul",
				'G', "George",
				'R', "Ringo"
			),
			result
		);
	}

	// using toMap() with duplicate keys throws an exeption if no merger is being provided
	@Test
	public void toMapWithDuplicatesThrows() {
		assertThrows(
			IllegalStateException.class,
			() ->
				Stream.of("John", "Paul", "George", "Ringo", "Peter")
					.collect(toMap(value -> value.charAt(0), Function.identity()))
		);
	}

	// toMap() allows you to provide a reduce function that will reduce multiple values
	// of the same key to one final result
	// do not use toMap() if you just need a collection of those values
	// Collectors.groupingBy is designed for that
	@Test
	public void toMapMergeFunction() {
		Map<Character, String> result =
			Stream.of("John", "Paul", "George", "Ringo", "Paul", "John", "Paul", "Peter")
				.collect(
					toMap(
						value -> value.charAt(0),
						Function.identity(),
						(left, right) -> right // we choose the last occurence
					));

		assertEquals(
			Map.of(
				'J', "John",
				'P', "Peter", // !!
				'G', "George",
				'R', "Ringo"
			),
			result
		);
	}

	// groupingBy() effectively creates a multimap
	@Test
	public void groupingBy() {
		Map<Character, List<String>> result =
			Stream.of("John", "Paul", "George", "Ringo", "Paul", "John", "Paul", "Peter")
				.collect(Collectors.groupingBy(value -> value.charAt(0)));

		assertEquals(
			Map.of(
				'J', List.of("John", "John"),
				'P', List.of("Paul", "Paul", "Paul", "Peter"),
				'G', List.of("George"),
				'R', List.of("Ringo")
			),
			result
		);
	}

	// making use of downstream collector for Collectors.groupingBy()
	@Test
	public void groupingByCounting() {
		Map<Character, Long> result =
			Stream.of("John", "Paul", "George", "Ringo", "Paul", "John", "Paul", "Peter")
				.collect(
					Collectors.groupingBy(
						value -> value.charAt(0),
						Collectors.counting() // downstream collector
					)
				);

		assertEquals(
			Map.of(
				'J', 2L,
				'P', 4L,
				'G', 1L,
				'R', 1L
			),
			result
		);
	}

	@Test
	public void groupingByAndJoiningToString() {
		String result =
			Stream.of("John", "Paul", "George", "Ringo")
				.collect(
					Collectors.joining(", ", "All names = [", "]")
				);

		assertEquals("All names = [John, Paul, George, Ringo]", result);
	}

	@Test
	public void groupingByAndReducing() {
		Map<Person.Gender, Integer> result =
			Stream.of(
				new Person("Leszek", MALE, 45, 2),
				new Person("Martha", FEMALE, 46, 2),
				new Person("Christopher", MALE, 21, 0),
				new Person("Hannah", FEMALE, 17, 0)
			).collect(
				Collectors.groupingBy(
					Person::gender,
					Collectors.summingInt(Person::age)
				)
			);

		assertEquals(
			Map.of(
				MALE, 66,
				FEMALE, 63
			),
			result
		);
	}


	// that is ... well useless, let's find a better way
	@Test
	public void groupingByAndFindingMaximum() {
		Map<Character, Optional<String>> result =
			Stream.of("John", "Paul", "George", "Ringo", "Paul", "John", "Paul", "Peter", "PretentiouslyLong")
				.collect(
					Collectors.groupingBy(
						value -> value.charAt(0),
						maxBy(Comparator.comparing(String::length))
					)
				);

		assertEquals(
			Map.of(
				'J', Optional.of("John"),
				'P', Optional.of("PretentiouslyLong"),
				'G', Optional.of("George"),
				'R', Optional.of("Ringo")
			),
			result
		);
	}

	// better alternative for Collectors.groupingBy() with maxBy() downstream collector
	@Test
	public void toMapMax() {
		Map<Character, String> result =
			Stream.of("John", "Paul", "George", "Ringo", "Paul", "John", "Paul", "Peter", "PretentiouslyLong")
				.collect(
					Collectors.toMap(
						value -> value.charAt(0),
						Function.identity(),
						BinaryOperator.maxBy(Comparator.comparing(String::length))
					)
				);

		assertEquals(
			Map.of(
				'J', "John",
				'P', "PretentiouslyLong",
				'G', "George",
				'R', "Ringo"
			),
			result
		);
	}

	// Collectors.mapping allow to transform the values in the target grouped bucket
	@Test
	public void collectorMapping() {
		Map<Person.Gender, List<Integer>> result =
			Stream.of(
				new Person("Leszek", MALE, 45, 2),
				new Person("Martha", FEMALE, 46, 2),
				new Person("Christopher", MALE, 21, 0),
				new Person("Hannah", FEMALE, 17, 0)
			).collect(
				Collectors.groupingBy(
					Person::gender,
					Collectors.mapping(Person::age, Collectors.toList())
				)
			);

		assertEquals(
			Map.of(
				MALE, List.of(45, 21),
				FEMALE, List.of(46, 17)
			),
			result
		);
	}
}
