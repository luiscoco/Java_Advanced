package com.luxoft.lmd.tasks;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.luxoft.lmd.model.Person;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CollectorsTask {
	private final ObjectMapper objectMapper = new ObjectMapper();
	private final List<Person> people;

	public CollectorsTask() {
		this.people = fetchPeople();
	}

	private List<Person> fetchPeople() {
		return fetchData(inputType, "task1-people");
	}


	@DisplayName("count the number of persons by gender")
	@Test public void task01() {
		Object result = null;

		assertEquals(expectedResult(1), result);
	}

	/*
		create a map of gender -> person names concatenation
		concatenation should be delimited with ", "
		prefixed with "#{"
		suffixed with "}#"
		concatenate only the names of persons
	 */
	@DisplayName("gender to names string")
	@Test public void task02() {
		Object result = null;

		assertEquals(expectedResult(2), result);
	}

	@DisplayName("average female age")
	@Test public void task03() {
		Object result = null;

		assertEquals(expectedResult(3), result);
	}

	@DisplayName("average age for each gender")
	@Test public void task04() {
		Object result = null;

		assertEquals(expectedResult(4), result);
	}

	@DisplayName("list of people sorted by name")
	@Test public void task05() {
		Object result = null;

		assertEquals(expectedResult(5), result);
	}

	@DisplayName("list of people sorted by gender, then name")
	@Test public void task06() {
		Object result = null;

		assertEquals(expectedResult(6), result);
	}

	@DisplayName("oldest person for each gender")
	@Test public void task07() {
		Object result = null;

		assertEquals(expectedResult(7), result);
	}


	@DisplayName("set of distinct female names")
	@Test public void task08() {
		Object result = null;

		assertEquals(expectedResult(8), result);
	}

	@DisplayName("list of males over 40 with no children")
	@Test public void task09() {
		Object result = null;

		assertEquals(expectedResult(9), result);
	}

	@DisplayName("map of person gender -> ( map of person age -> sorted set of person names )")
	@Test public void task10() {
		Object result = null;

		assertEquals(expectedResult(10), result);
	}

	@DisplayName("total children count")
	@Test public void task11() {
		Object result = null;

		assertEquals(expectedResult(11), result);
	}

	@DisplayName("total people count (including children)")
	@Test public void task12() {
		// this requires a usage of a collector not mentioned in the course
		Object result = null;

		assertEquals(expectedResult(12), result);
	}

	@DisplayName("length of person name -> how many persons have name of that length")
	@Test public void task13() {
		Object result = null;

		assertEquals(expectedResult(13), result);
	}

	@DisplayName("how many letters all names have?")
	@Test public void task14() {
		Object result = null;

		assertEquals(expectedResult(14), result);
	}

	@DisplayName("how many letters all names by gender have?")
	@Test public void task15() {
		Object result = null;

		assertEquals(expectedResult(15), result);
	}


	private <T> T expectedResult(int taskNumber) {
		NumberFormat format = getNumberFormat();

		return (T) fetchData(returnTypes.get(taskNumber - 1), "task1-" + format.format(taskNumber));
	}

	private static NumberFormat getNumberFormat() {
		NumberFormat format = NumberFormat.getIntegerInstance();
		format.setMinimumIntegerDigits(2);
		return format;
	}

	private <T> T fetchData(TypeReference<T> typeReference, String name) {
		try {
			return objectMapper.readerFor(typeReference)
				.readValue(new File("src/main/resources/" + name + ".json"));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	// @formatter:off
	private final TypeReference<List<Person>> inputType = new TypeReference<List<Person>>() {};
	private final List<TypeReference<?>> returnTypes =
		List.of(
			new TypeReference<Map<Person.Gender,Long>>() {}, // 01
			new TypeReference<Map<Person.Gender,String>>() {}, // 02
			new TypeReference<Double>() {}, // 03
			new TypeReference<Map<Person.Gender, Double>>() {}, // 04
			new TypeReference<List<Person>>() {}, // 05
			new TypeReference<List<Person>>() {}, // 06
			new TypeReference<Map<Person.Gender, Person>>() {}, // 07
			new TypeReference<Set<String>>() {}, // 08
			new TypeReference<List<Person>>() {}, // 09
			new TypeReference<Map<Person.Gender, Map<Integer, TreeSet<String>>>>() {}, // 10
			new TypeReference<Integer>() {}, // 11
			new TypeReference<Integer>() {}, // 12
			new TypeReference<Map<Integer, Long>>() {}, // 13
			new TypeReference<Long>() {}, // 14
			new TypeReference<Map<Person.Gender, Long>>() {} // 15
		);
	// @formatter:on
}
