package com.luxoft.lmd.datastreams.sequential;

import org.junit.jupiter.api.Test;

import java.util.Collection;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

public class FlatMap {
	@Test
	public void streamOfCollections() {
		List<Integer> list1 = List.of(1, 2, 3, 4, 5, 6, 7);
		List<Integer> list2 = List.of(12, 14, 16);
		List<Integer> list3 = List.of(23, 25, 77);
		List<List<Integer>> result =
			Stream.of(list1, list2, list3)
				.toList();

		assertEquals(
			List.of(
				List.of(1, 2, 3, 4, 5, 6, 7),
				List.of(12, 14, 16),
				List.of(23, 25, 77)
			),
			result
		);
	}

	@Test
	public void flatMap() {
		List<Integer> list1 = List.of(1, 2, 3, 4, 5, 6, 7);
		List<Integer> list2 = List.of(12, 14, 16);
		List<Integer> list3 = List.of(23, 25, 27);
		List<Integer> result =
			Stream.of(list1, list2, list3)
				.flatMap(Collection::stream)
				.toList();

		assertEquals(
			List.of(1, 2, 3, 4, 5, 6, 7, 12, 14, 16, 23, 25, 27),
			result
		);
	}

	// does not make sense to use mapMulti in such easy case -
	// always choose the simplest solution possible
	@Test public void flatMapMulti() {
		List<Integer> list1 = List.of(1, 2, 3, 4, 5, 6, 7);
		List<Integer> list2 = List.of(12, 14, 16);
		List<Integer> list3 = List.of(23, 25, 27);

		// https://www.baeldung.com/java-mapmulti
		// imperative approach of mapMulti gives more freedom to process elements
		// choose yourself which code is more readable

		// flatMap cannot produce a parallel stream!
		// you can attempt to mark it as .parallel() but it will switch to sequential anyways.

		List<Integer> result =
			Stream.of(list1, list2, list3)
				.mapMulti(
					(List<Integer> values, Consumer<Integer> consumer) ->
						values.forEach(val -> {
								if (val % 2 == 0)
									consumer.accept(val + 1);
							}
						)
				).toList();

		// same could be done with:
		List<Integer> result2 =
			Stream.of(list1, list2, list3)
				.flatMap(Collection::stream)
				.filter(val -> val % 2 == 0)
				.map(val -> val + 1)
				.toList();

		assertAll(
			() -> assertEquals(List.of(3, 5, 7, 13, 15, 17), result),
			() -> assertIterableEquals(result, result2)
		);
	}
}
