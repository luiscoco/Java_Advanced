package com.luxoft.lmd.executors;

import net.datafaker.Faker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.util.concurrent.Callable;

public class StringGenerator implements Callable<String> {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	private final Faker faker = new Faker();


	public String call() throws Exception {
		String str = faker.animal().name();

		try (var ignored = MDC.putCloseable("taskName", str)) {
			logger.info("⏵");
			Thread.sleep(1000);
			logger.info("⏹");
		}

		return str;
	}
}
