package com.luxoft.lmd.datastreams.parallel;

import net.datafaker.Faker;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ParallelStreams {
	private final Faker faker = new Faker();
	private Logger logger = LoggerFactory.getLogger(getClass());

	@Test public void sum() {
		IntStream.rangeClosed(1, 1000_000_000)
			.parallel()
			.sum();
	}

	@Test public void forEach() {
		IntStream.range(0, 1000)
			.parallel()
			.forEach(System.out::println);
	}

	@Test public void forEachOrdered() {
		IntStream.range(0, 1000)
			.parallel()
			.forEachOrdered(System.out::println);
	}

	@Test public void parallelStreamFromCollection() {
		List<String> list =
			faker.collection(() -> faker.funnyName().name())
				.len(1_000_000)
				.generate();

		TimedResult<Long> parallel =
			Timing.runTimed(
				"parallel",
				() ->
					list.parallelStream()
						// why commenting out flatMap works crazy fast?
						.flatMap(val -> Arrays.stream(val.split("")))
						.count()
			);

		logger.info("parallel from linked list: {}ms", parallel.duration().toMillis());
	}

	@Test public void forEachDoNotDoThat() {
		List<Integer> result = new ArrayList<>();

		IntStream.range(0, 1000)
			.parallel()
			.forEach(result::add);

		System.out.println("result.size() = " + result.size());
	}

	@Test public void thisIsSafeButPrettyBadlyWritten() {
		ConcurrentHashMap.KeySetView<Integer, Boolean> result = ConcurrentHashMap.newKeySet();

		// write a custom concurrent collector for that

		IntStream.range(0, 1000)
			.parallel()
			.forEach(result::add);

		assertEquals(1000, result.size());
	}

	@Test public void thisWorksButWillGetYouFired() {
		List<Integer> result = new ArrayList<>();

		IntStream.range(0, 1000)
			.parallel()
			.forEachOrdered(result::add);

		assertEquals(1000, result.size());
	}

}
